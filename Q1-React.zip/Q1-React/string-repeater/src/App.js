import React, { useState } from "react";
import StringForm from "./StringForm";
import "./App.css";

function App() {
  const [result, setResult] = useState("");

  function handleSubmit(userinput) {
    // Repeat the inputted string based on the inputted number
    setResult(userinput.stringEntered.repeat(userinput.numberEntered));
  };

  return (
    <div className="App">
      <header className="App-header">
        <p>String Multiplier</p>
        <StringForm onSaveNewString={handleSubmit} />
        {result && <p>{result}</p>}
      </header>
    </div>
  );
}

export default App;
