import React, { useState } from "react";
import Items from "./components/Items/Items";
import NewItem from "./components/NewItem/NewItem";

const DUMMY_LIST = [
  {
    id: "1",
    title: "Get Toilet Paper",
  },
  {
    id: "2",
    title: "Buy New TV",
  },
  {
    id: "3",
    title: "Renew Car Insurance",
  },
  {
    id: "4",
    title: "Pay the Electricity Bill",
  },
];

function App() {
  const [todos, setToDos] = useState(DUMMY_LIST);

  function addItemHandler(item) {
    // console.log("In App.js");
    // console.log(item);
    setToDos((prevItems) => {
      return [item, ...prevItems];
    });
  }

  return (
    <div>
      <NewItem onAddItem={addItemHandler} />
      <Items items={todos} setToDos={setToDos} />
    </div>
  );
}

export default App;
