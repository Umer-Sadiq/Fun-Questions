import React from "react";
import Card from "../UI/Card";
import "./ToDoItem.css";

function ToDoItem(props) {
  const title = props.title;
  function deleteToDoHandler() {
    props.onDeleteToDo(props.id);
  };

  return (
    <Card className="todo-item">
      <div className="todo-item__description">
        <div>{title}</div>
        <button onClick={deleteToDoHandler}>Delete</button>
      </div>
    </Card>
  );
}

export default ToDoItem;
