import React from "react";
import ToDoItem from "./ToDoItem";
import Card from "../UI/Card";
import "./Items.css";

function Items(props) {
  function deleteToDoHandler(id)  {
    // Filter out the item with the given id
    const updatedToDos = props.items.filter((item) => item.id !== id);
    // Call setToDos to update the state in the parent component
    props.setToDos(updatedToDos);
  };
  return (
    <div>
      <Card className="items">
        {props.items.map((item) => (
          <ToDoItem
            key={item.id}
            id={item.id}
            title={item.title}
            onDeleteToDo={deleteToDoHandler}
          />
        ))}
      </Card>
    </div>
  );
}

export default Items;
