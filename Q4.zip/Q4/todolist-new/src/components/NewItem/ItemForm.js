import React, { useState } from "react";
import "./ItemForm.css";

function ItemForm(props) {
  const [enteredTitle, setEnteredTitle] = useState("");

  function titleChangeHandler(event) {
    setEnteredTitle(event.target.value);
  }

  function submitHandler(event) {
    event.preventDefault();
    const itemData = {
      title: enteredTitle,
    };
    //console.log(itemData);
    props.onSaveItemData(itemData);
    setEnteredTitle("");
  }

  return (
    <form onSubmit={submitHandler}>
      <div className="new-item__controls">
        <div className="new-item__control">
          <label>To-do Item</label>
          <input
            type="text"
            value={enteredTitle}
            onChange={titleChangeHandler}
          />
        </div>
      </div>
      <div className="new-item__actions">
        <button>Add Item</button>
      </div>
    </form>
  );
}

export default ItemForm;
