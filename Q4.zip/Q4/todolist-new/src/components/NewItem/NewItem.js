import React from "react";
import "./NewItem.css";
import ItemForm from "./ItemForm";
function NewItem(props) {
  function saveItemDataHandler(enteredItemData) {
    const itemData = {
      ...enteredItemData,
      id: Math.random().toString(),
    };
    //console.log(itemData);
    props.onAddItem(itemData);
  }
  return (
    <div className="new-item">
      <ItemForm onSaveItemData={saveItemDataHandler} />
    </div>
  );
}

export default NewItem;
