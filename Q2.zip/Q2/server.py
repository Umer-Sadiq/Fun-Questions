from flask import Flask, request, jsonify

app = Flask(__name__)

# Dictionary to store registered users
users = {}

# Endpoint for user registration
@app.route('/register_user', methods=['POST'])
def register():
    # GET username and password from register_user request
    username = request.json.get('username')
    password = request.json.get('password')
    
    # Error if username already exists
    if username in users:
        return jsonify({'message': 'Username already exists'}), 400
    
    # Store credentials in users dictionary
    users[username] = password
    
    return jsonify({'message': 'User registered successfully'}), 201

# Endpoint for user login
@app.route('/login', methods=['POST'])
def login():
    # GET username and password from login request
    username = request.json.get('username')
    password = request.json.get('password')
    
    # Check if username and password match the users dictionary
    if username in users and users[username] == password:
        return jsonify({'message': 'Access granted'})
    else:
        return jsonify({'message': 'Access denied'}), 401

if __name__ == '__main__':
    app.run(debug=True)