import React, { useState } from "react";
import "./StringForm.css";

function StringForm(props) {
  const [stringInput, setStringInput] = useState("");
  const [numberInput, setInputNumber] = useState("");
  const [error, setError] = useState("");

  const stringChangeHandler = (e) => {
    const { value } = e.target;
    setStringInput(value);
  };

  const numberChangeHandler = (e) => {
    const { value } = e.target;
    setInputNumber(value);
  };

  const submitHandler = (e) => {
    e.preventDefault();

    // Validate the string and number inputs
    if (!stringInput || !numberInput) {
      setError("Please fill both fields.");
    } else if (isNaN(numberInput)) {
      setError("Please enter a valid number.");
    } else {
      const passedData = {
        stringEntered: stringInput,
        numberEntered: Number(numberInput),
      };
      // Repeat the inputted string based on the inputted number
      props.onSaveNewString(passedData);
      //props.onSaveNewString(stringInput, Number(numberInput));
      setStringInput("");
      setInputNumber("");
      setError("");
    }
  };

  return (
    <div>
      <div className="new-string">
        <form onSubmit={submitHandler}>
          <div className="new-stringform__controls">
            <div className="new-stringform__control">
              <input
                type="text"
                value={stringInput}
                onChange={stringChangeHandler}
                placeholder="Enter a string"
              />
            </div>
            <div className="new-stringform__control">
              <input
                type="number"
                value={numberInput}
                min="0"
                step="1"
                onChange={numberChangeHandler}
                placeholder="Enter a number"
              />
            </div>
          </div>
          <div className="new-stringform__actions">
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
      {error && <p style={{ color: "#990000" }}>{error}</p>}
    </div>
  );
}

export default StringForm;
